import React, { useState, useEffect } from "react";

function App() {
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    dob: "",
    gender: "",
    address: "",
  });

  const { firstName, lastName, email, phone, dob, gender, address } = formData;
  const [savedData, setSavedData] = useState(null);
  const [isEditing, setIsEditing] = useState(false);

  useEffect(() => {
    const storedData = localStorage.getItem("personalInfo");
    if (storedData) setSavedData(JSON.parse(storedData));
  }, []);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    localStorage.setItem("personalInfo", JSON.stringify(formData));
    setSavedData(formData);
    setIsEditing(false);
    setFormData({
      firstName: "",
      lastName: "",
      email: "",
      phone: "",
      dob: "",
      gender: "",
      address: "",
    });
  };

  const handleEdit = () => {
    setFormData(savedData);
    setIsEditing(true);
  };

  const handleDelete = () => {
    localStorage.removeItem("personalInfo");
    setSavedData(null);
    setFormData({
      firstName: "",
      lastName: "",
      email: "",
      phone: "",
      dob: "",
      gender: "",
      address: "",
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-100 via-pink-100 to-yellow-100 flex flex-col items-center py-8">
      <h1 className="text-4xl font-bold mb-6 text-purple-800 drop-shadow-lg">
        Personal Infomation Manager
      </h1>

      <form
        onSubmit={handleSubmit}
        className="bg-white/80 backdrop-blur-sm p-6 rounded-xl shadow-xl w-full max-w-lg space-y-4 border border-purple-300"
      >
        <input
          type="text"
          name="firstName"
          placeholder="First Name"
          value={firstName}
          onChange={handleChange}
          className="w-full border border-purple-300 p-2 rounded focus:outline-none focus:ring-2 focus:ring-purple-500"
          required
        />
        <input
          type="text"
          name="lastName"
          placeholder="Last Name"
          value={lastName}
          onChange={handleChange}
          className="w-full border border-purple-300 p-2 rounded focus:outline-none focus:ring-2 focus:ring-purple-500"
          required
        />
        <input
          type="email"
          name="email"
          placeholder="Email"
          value={email}
          onChange={handleChange}
          className="w-full border border-purple-300 p-2 rounded focus:outline-none focus:ring-2 focus:ring-purple-500"
          required
        />
        <input
          type="number"
          name="phone"
          placeholder="Phone"
          value={phone}
          onChange={handleChange}
          className="w-full border border-purple-300 p-2 rounded focus:outline-none focus:ring-2 focus:ring-purple-500"
          required
        />
        <input
          type="date"
          name="dob"
          value={dob}
          onChange={handleChange}
          className="w-full border border-purple-300 p-2 rounded focus:outline-none focus:ring-2 focus:ring-purple-500"
          required
        />
        <div className="flex gap-4 text-purple-700">
          {["Male", "Female", "Other"].map((g) => (
            <label key={g}>
              <input
                type="radio"
                name="gender"
                value={g}
                checked={gender === g}
                onChange={handleChange}
              />{" "}
              {g}
            </label>
          ))}
        </div>
        <textarea
          name="address"
          placeholder="Address"
          value={address}
          onChange={handleChange}
          className="w-full border border-purple-300 p-2 rounded focus:outline-none focus:ring-2 focus:ring-purple-500"
          required
        ></textarea>
        <button
          type="submit"
          className="bg-purple-600 hover:bg-purple-700 text-white px-6 py-2 rounded-lg w-full shadow-md transition"
        >
          {isEditing ? "Update" : "Submit"}
        </button>
      </form>

      {savedData && (
        <div className="bg-white/90 backdrop-blur-sm shadow-xl rounded-2xl p-6 mt-6 w-full max-w-lg border border-pink-300">
          <h2 className="text-2xl font-semibold text-purple-800 mb-4">
            Saved User Info
          </h2>
          <div className="flex flex-col gap-3">
            {Object.entries(savedData).map(([key, value]) => (
              <div
                key={key}
                className="bg-gradient-to-r from-purple-100 to-pink-100 p-3 rounded-lg shadow-sm"
              >
                <span className="block font-semibold capitalize text-purple-700">
                  {key}:
                </span>
                <span className="text-gray-700">{value}</span>
              </div>
            ))}
          </div>
          <div className="flex gap-4 mt-4">
            <button
              onClick={handleEdit}
              className="bg-green-500 hover:bg-green-600 px-4 py-2 rounded text-white"
            >
              Edit
            </button>
            <button
              onClick={handleDelete}
              className="bg-red-500 hover:bg-red-600 px-4 py-2 rounded text-white"
            >
              Delete
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
